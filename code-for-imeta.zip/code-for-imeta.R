
#Required R package
library('ggpmisc')
library("gridExtra")
library("cowplot")
library('broom')
library('car')


mytheme<-theme(
  text = element_text(family = 'serif'),
  plot.margin = unit(c(1.2,1.2,1,1), 'cm'),
  axis.title.x = element_text(size=60,color = 'black', vjust = -1),
  axis.title.y = element_text(size=60,color = 'black', vjust = 2, hjust = 0.5),
  axis.text= element_text(size=60, color = 'black'), 
  axis.ticks = element_line(linewidth=1.5),
  axis.ticks.length = unit(0.3, 'cm'),
  panel.grid = element_blank(),
  panel.background = element_rect(fill = 'white',color='black', linewidth=2), 
  legend.title = element_blank(),
  legend.text = element_text(size=60),
  legend.key.size = unit(1.1, 'cm'),
  strip.text.x = element_text(size = 60)) #Sets the theme of the drawing panel

data1 <- read.csv("data1_topological_parameter.csv",head=T) #Import data

data1$treatment <- factor(data1$treatment, levels = c('N0', 'N1', 'N2', 'N4', 'N8', 'N16', 'N32', 'N64'))#颜色

p1<-ggplot(data1, aes(x=Treatment,y=bac_nodes_num)) +
  geom_point(aes(colour= treatment), size = 16,alpha=1) +
  stat_smooth(method=lm,formula= y~x,size=1.5,linetype =1,colour="black",se=FALSE)+
  stat_fit_glance(method = "lm",method.args = list(formula=y~x),
                  mapping = aes(label = sprintf('italic(R^2)~"="~%.2f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE)+
  scale_color_manual(values = c('N0'= "#8B0000", 'N1'= "#8E4848", 'N2'= "#8F6060", 'N4'= "#908080", 
                                'N8'= "grey71", 'N16'= "#8BB6B6", 'N32'= "#4F9A9A", 'N64'= "#296060"))+ 
  xlab(expression(Log2(N_input)))+
  ylab(expression(bac_nodes_num))+mytheme+xlim(-0.5, 6.5)+ylim(350, 1000) #Modify the value of the axis scale

p1

p2<-ggplot(data1, aes(x=Treatment,y=bac_edges_num)) +
  geom_point(aes(colour= treatment), size = 16,alpha=1) +
  stat_smooth(method=lm,formula= y~x,size=1.5,linetype =1,colour="black",se=FALSE)+
  stat_fit_glance(method = "lm",method.args = list(formula=y~x),
                  mapping = aes(label = sprintf('italic(R^2)~"="~%.2f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE)+
  scale_color_manual(values = c('N0'= "#8B0000", 'N1'= "#8E4848", 'N2'= "#8F6060", 'N4'= "#908080", 
                                'N8'= "grey71", 'N16'= "#8BB6B6", 'N32'= "#4F9A9A", 'N64'= "#296060"))+
  xlab(expression(Log2(N_input)))+
  ylab(expression(bac_edges_num))+mytheme+xlim(-0.5, 6.5)+ylim(750, 3600)  #Modify the value of the axis scale
p2

p3<-ggplot(data1, aes(x=Treatment,y=bac_average_degree)) +
  geom_point(aes(colour= treatment), size = 16,alpha=1) +
  stat_smooth(method=lm,formula= y~x,size=1.5,linetype =1,colour="black",se=FALSE)+
  stat_fit_glance(method = "lm",method.args = list(formula=y~x),
                  mapping = aes(label = sprintf('italic(R^2)~"="~%.3f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE)+
  scale_color_manual(values = c('N0'= "#8B0000", 'N1'= "#8E4848", 'N2'= "#8F6060", 'N4'= "#908080", 
                                'N8'= "grey71", 'N16'= "#8BB6B6", 'N32'= "#4F9A9A", 'N64'= "#296060"))+
  xlab(expression(Log2(N_input)))+
  ylab(expression(bac_average_degree))+mytheme+xlim(-0.5, 6.5)+
  scale_y_continuous(labels = scales::number_format(accuracy = 0.01), limits = c(4, 8))  #Modify the value of the axis scale

p3

p4<-ggplot(data1, aes(x=Treatment,y=bac_clustering_coefficient)) +
  geom_point(aes(colour= treatment), size = 16,alpha=1) +
  stat_smooth(method=lm,formula= y~x,size=1.5,linetype =1,colour="black",se=FALSE)+
  stat_fit_glance(method = "lm",method.args = list(formula=y~x),
                  mapping = aes(label = sprintf('italic(R^2)~"="~%.3f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE)+
  scale_color_manual(values = c('N0'= "#8B0000", 'N1'= "#8E4848", 'N2'= "#8F6060", 'N4'= "#908080", 
                                'N8'= "grey71", 'N16'= "#8BB6B6", 'N32'= "#4F9A9A", 'N64'= "#296060"))+
  xlab(expression(Log2(N_input)))+
  ylab(expression(bac_clustering_coefficient))+mytheme+xlim(-0.5, 6.5)+ylim(0.576, 0.7)  #Modify the value of the axis scale

p4

p5<-ggplot(data1, aes(x=Treatment,y=bac_modularity)) +
  geom_point(aes(colour= treatment), size = 16,alpha=1) +
  stat_smooth(method=lm,formula= y~x,size=1.5,linetype =1,colour="black",se=FALSE)+
  stat_fit_glance(method = "lm",method.args = list(formula=y~x),
                  mapping = aes(label = sprintf('italic(R^2)~"="~%.3f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE)+
  scale_color_manual(values = c('N0'= "#8B0000", 'N1'= "#8E4848", 'N2'= "#8F6060", 'N4'= "#908080", 
                                'N8'= "grey71", 'N16'= "#8BB6B6", 'N32'= "#4F9A9A", 'N64'= "#296060"))+
  xlab(expression(Log2(N_input)))+
  ylab(expression(bac_modularity))+mytheme+ xlim(-0.5, 6.5)+
  scale_y_continuous(labels = scales::number_format(accuracy = 0.001), limits = c(0.75, 0.95)) #Modify the value of the axis scale

p5

p6<-ggplot(data1, aes(x=Treatment,y=bac_average_path_length)) +
  geom_point(aes(colour= treatment), size = 16,alpha=1) +
  stat_smooth(method=lm,formula= y~x,size=1.5,linetype =1,colour="black",se=FALSE)+
  stat_fit_glance(method = "lm",method.args = list(formula=y~x),
                  mapping = aes(label = sprintf('italic(R^2)~"="~%.3f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE)+
  scale_color_manual(values = c('N0'= "#8B0000", 'N1'= "#8E4848", 'N2'= "#8F6060", 'N4'= "#908080", 
                                'N8'= "grey71", 'N16'= "#8BB6B6", 'N32'= "#4F9A9A", 'N64'= "#296060"))+
  xlab(expression(Log2(N_input)))+
  ylab(expression(bac_average_path_length))+mytheme+xlim(-0.5, 6.5)+  
  scale_y_continuous(labels = scales::number_format(accuracy = 1), limits = c(5, 25)) #Modify the value of the axis scale
p6

p7<-ggplot(data1, aes(x=Treatment,y=bac_graph_density)) +
  geom_point(aes(colour= treatment), size = 16,alpha=1) +
  stat_smooth(method=lm,formula= y~x,size=1.5,linetype =1,colour="black",se=FALSE)+
  stat_fit_glance(method = "lm",method.args = list(formula=y~x),
                  mapping = aes(label = sprintf('italic(R^2)~"="~%.3f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE)+
  scale_color_manual(values = c('N0'= "#8B0000", 'N1'= "#8E4848", 'N2'= "#8F6060", 'N4'= "#908080", 
                                'N8'= "grey71", 'N16'= "#8BB6B6", 'N32'= "#4F9A9A", 'N64'= "#296060"))+
  xlab(expression(Log2(N_input)))+
  ylab(expression(bac_graph_density))+mytheme+xlim(-0.5, 6.5)+ 
  scale_y_continuous(labels = scales::number_format(accuracy = 0.002), limits = c(0.005, 0.014)) #Modify the value of the axis scale
p7 

p8<-ggplot(data1, aes(x=Treatment,y=bac_PC1)) +
  geom_point(aes(colour= treatment), size = 16,alpha=1) +
  stat_smooth(method=lm,formula= y~x,size=1.5,linetype =1,colour="black",se=FALSE)+
  stat_fit_glance(method = "lm",method.args = list(formula=y~x),
                  mapping = aes(label = sprintf('italic(R^2)~"="~%.3f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE)+
  scale_color_manual(values = c('N0'= "#8B0000", 'N1'= "#8E4848", 'N2'= "#8F6060", 'N4'= "#908080", 
                                'N8'= "grey71", 'N16'= "#8BB6B6", 'N32'= "#4F9A9A", 'N64'= "#296060"))+
  xlab(expression(Log2(N_input)))+
  ylab(expression(bac_PC1))+mytheme+xlim(-0.5, 6.5)+  
  scale_y_continuous(labels = scales::number_format(accuracy = 0.1), limits = c(-5, 3)) #Modify the value of the axis scale
p8

plot_grid(p1, p2, p3, p4, p5, p6, p7, p8,     
          labels = c('(A)', '(B)', '(C)', '(D)', 
                     '(E)', '(F)'), ncol = 4, nrow = 2) #Bacterial topological parameter 



p1<-ggplot(data1, aes(x=Treatment,y=bac_positive.cor_num)) +
  geom_point(aes(colour= treatment), size = 16,alpha=1) +
  stat_smooth(method=lm,formula= y~x,size=1.5,linetype =1,colour="black",se=FALSE)+
  stat_fit_glance(method = "lm",method.args = list(formula=y~x),
                  mapping = aes(label = sprintf('italic(R^2)~"="~%.3f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE)+
  scale_color_manual(values = c('N0'= "#8B0000", 'N1'= "#8E4848", 'N2'= "#8F6060", 'N4'= "#908080", 
                                'N8'= "grey71", 'N16'= "#8BB6B6", 'N32'= "#4F9A9A", 'N64'= "#296060"))+
  xlab(expression(Log2(N_input)))+
  ylab(expression(bac_positive.cor_num))+mytheme+xlim(-0.5, 6.5)+ylim(710, 3600)  

p1


p2<-ggplot(data1, aes(x=Treatment,y=bac_negative.cor_num)) +
  geom_point(aes(colour= treatment), size = 16,alpha=1) +
  stat_smooth(method=lm,formula= y~x,size=1.5,linetype =1,colour="black",se=FALSE)+
  stat_fit_glance(method = "lm",method.args = list(formula=y~x),
                  mapping = aes(label = sprintf('italic(R^2)~"="~%.3f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE)+
  scale_color_manual(values = c('N0'= "#8B0000", 'N1'= "#8E4848", 'N2'= "#8F6060", 'N4'= "#908080", 
                                'N8'= "grey71", 'N16'= "#8BB6B6", 'N32'= "#4F9A9A", 'N64'= "#296060"))+
  xlab(expression(Log2(N_input)))+
  ylab(expression(bac_negative.cor_num))+mytheme+xlim(-0.5, 6.5)+ 
  scale_y_continuous(labels = scales::number_format(accuracy = 1), limits = c(-50, 530)) 

p2 

plot_grid(p1, p2,      
          labels = c('(A)', '(B)'), ncol = 2, nrow = 1) #Bacterial positively and negatively correlated edges (Fig.S1)





p1<-ggplot(data1, aes(x=Treatment,y=fungi_nodes_num)) +
  geom_point(aes(colour= treatment), size = 16,alpha=1) +
  stat_smooth(method=lm,formula= y~x,size=1.5,linetype =1,colour="black",se=FALSE)+
  stat_fit_glance(method = "lm",method.args = list(formula=y~x),
                  mapping = aes(label = sprintf('italic(R^2)~"="~%.2f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE)+
  scale_color_manual(values = c('N0'= "#8B0000", 'N1'= "#8E4848", 'N2'= "#8F6060", 'N4'= "#908080", 
                                'N8'= "grey71", 'N16'= "#8BB6B6", 'N32'= "#4F9A9A", 'N64'= "#296060" ))+
  xlab(expression(Log2(N_input)))+
  ylab(expression(fungi_nodes_num))+mytheme+xlim(-0.5, 6.5)+ylim(250, 330)

p1

p2<-ggplot(data1, aes(x=Treatment,y=fungi_edges_num)) +
  geom_point(aes(colour= treatment), size = 16,alpha=1) +
  stat_smooth(method=lm,formula= y~x,size=1.5,linetype =1,colour="black",se=FALSE)+
  stat_fit_glance(method = "lm",method.args = list(formula=y~x),
                  mapping = aes(label = sprintf('italic(R^2)~"="~%.2f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE)+
  scale_color_manual(values = c('N0'= "#8B0000", 'N1'= "#8E4848", 'N2'= "#8F6060", 'N4'= "#908080", 
                                'N8'= "grey71", 'N16'= "#8BB6B6", 'N32'= "#4F9A9A", 'N64'= "#296060"))+
  xlab(expression(Log2(N_input)))+
  ylab(expression(fungi_edges_num))+mytheme+xlim(-0.5, 6.5)+ylim(500, 1200)  
p2

p3<-ggplot(data1, aes(x=Treatment,y=fungi_average_degree)) +
  geom_point(aes(colour= treatment), size = 16,alpha=1) +
  stat_smooth(method=lm,formula= y~x,size=1.5,linetype =1,colour="black",se=FALSE)+
  stat_fit_glance(method = "lm",method.args = list(formula=y~x),
                  mapping = aes(label = sprintf('italic(R^2)~"="~%.3f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE)+
  scale_color_manual(values = c('N0'= "#8B0000", 'N1'= "#8E4848", 'N2'= "#8F6060", 'N4'= "#908080", 
                                'N8'= "grey71", 'N16'= "#8BB6B6", 'N32'= "#4F9A9A", 'N64'= "#296060"))+
  xlab(expression(Log2(N_input)))+
  ylab(expression(fungi_average_degree))+mytheme+xlim(-0.5, 6.5)+
  scale_y_continuous(labels = scales::number_format(accuracy = 0.01), limits = c(3.5, 7))  

p3

p4<-ggplot(data1, aes(x=Treatment,y=fungi_clustering_coefficient)) +
  geom_point(aes(colour= treatment), size = 16,alpha=1) +
  stat_smooth(method=lm,formula= y~x,size=1.5,linetype =1,colour="black",se=FALSE)+
  stat_fit_glance(method = "lm",method.args = list(formula=y~x),
                  mapping = aes(label = sprintf('italic(R^2)~"="~%.3f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE)+
  scale_color_manual(values = c('N0'= "#8B0000", 'N1'= "#8E4848", 'N2'= "#8F6060", 'N4'= "#908080", 
                                'N8'= "grey71", 'N16'= "#8BB6B6", 'N32'= "#4F9A9A", 'N64'= "#296060"))+
  xlab(expression(Log2(N_input)))+
  ylab(expression(fungi_clustering_coefficient))+mytheme+xlim(-0.5, 6.5)+ylim(0.6, 0.8)  

p4

p5<-ggplot(data1, aes(x=Treatment,y=fungi_modularity)) +
  geom_point(aes(colour= treatment), size = 16,alpha=1) +
  stat_smooth(method=lm,formula= y~x,size=1.5,linetype =1,colour="black",se=FALSE)+
  stat_fit_glance(method = "lm",method.args = list(formula=y~x),
                  mapping = aes(label = sprintf('italic(R^2)~"="~%.3f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE)+
  scale_color_manual(values = c('N0'= "#8B0000", 'N1'= "#8E4848", 'N2'= "#8F6060", 'N4'= "#908080", 
                                'N8'= "grey71", 'N16'= "#8BB6B6", 'N32'= "#4F9A9A", 'N64'= "#296060"))+
  xlab(expression(Log2(N_input)))+
  ylab(expression(fungi_modularity))+mytheme+xlim(-0.5, 6.5)+
  scale_y_continuous(labels = scales::number_format(accuracy = 0.01), limits = c(0.62, 0.93))
p5

p6<-ggplot(data1, aes(x=Treatment,y=fungi_average_path_length)) +
  geom_point(aes(colour= treatment), size = 16,alpha=1) +
  stat_smooth(method=lm,formula= y~x,size=1.5,linetype =1,colour="black",se=FALSE)+
  stat_fit_glance(method = "lm",method.args = list(formula=y~x),
                  mapping = aes(label = sprintf('italic(R^2)~"="~%.3f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE)+
  scale_color_manual(values = c('N0'= "#8B0000", 'N1'= "#8E4848", 'N2'= "#8F6060", 'N4'= "#908080", 
                                'N8'= "grey71", 'N16'= "#8BB6B6", 'N32'= "#4F9A9A", 'N64'= "#296060"))+
  xlab(expression(Log2(N_input)))+
  ylab(expression(fungi_average_path_length))+mytheme+xlim(-0.5, 6.5)+  
  scale_y_continuous(labels = scales::number_format(accuracy = 0.01), limits = c(1.5, 9)) 
p6

p7<-ggplot(data1, aes(x=Treatment,y=fungi_graph_density)) +
  geom_point(aes(colour= treatment), size = 16,alpha=1) +
  stat_smooth(method=lm,formula= y~x,size=1.5,linetype =1,colour="black",se=FALSE)+
  stat_fit_glance(method = "lm",method.args = list(formula=y~x),
                  mapping = aes(label = sprintf('italic(R^2)~"="~%.3f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE)+
  scale_color_manual(values = c('N0'= "#8B0000", 'N1'= "#8E4848", 'N2'= "#8F6060", 'N4'= "#908080", 
                                'N8'= "grey71", 'N16'= "#8BB6B6", 'N32'= "#4F9A9A", 'N64'= "#296060"))+
  xlab(expression(Log2(N_input)))+
  ylab(expression(fungi_graph_density))+mytheme+xlim(-0.5, 6.5)+  
  scale_y_continuous(labels = scales::number_format(accuracy = 0.001), limits = c(0.01, 0.025)) 
p7 

p8<-ggplot(data1, aes(x=Treatment,y=fungi_PC1)) +
  geom_point(aes(colour= treatment), size = 16,alpha=1) +
  stat_smooth(method=lm,formula= y~x,size=1.5,linetype =1,colour="black",se=FALSE)+
  stat_fit_glance(method = "lm",method.args = list(formula=y~x),
                  mapping = aes(label = sprintf('italic(R^2)~"="~%.3f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE)+
  scale_color_manual(values = c('N0'= "#8B0000", 'N1'= "#8E4848", 'N2'= "#8F6060", 'N4'= "#908080", 
                                'N8'= "grey71", 'N16'= "#8BB6B6", 'N32'= "#4F9A9A", 'N64'= "#296060"))+
  xlab(expression(Log2(N_input)))+
  ylab(expression(fungi_PC1))+mytheme+xlim(-0.5, 6.5)+  
  scale_y_continuous(labels = scales::number_format(accuracy = 0.1), limits = c(-5, 3)) 
p8

plot_grid(p1, p2, p3, p4, p5, p6, p7, p8,     
          labels = c('(A)', '(B)', '(C)', '(D)', 
                     '(E)', '(F)'), ncol = 4, nrow = 2) #Fungal topological parameter (Fig.S2)



data2 <- read.csv("data2_bacterial_parameter.csv",head=T) #Import data

data2$treatment <- factor(data2$treatment, levels = c('N0', 'N1', 'N2', 'N4', 'N8', 'N16', 'N32', 'N64'))#颜色

p1<-ggplot(data2, aes(x=Treatment,y=copiotroph/oligotroph_ratio)) +
  geom_point(aes(colour= treatment), size = 25,alpha=1) +
  stat_smooth(method=lm,formula= y~x,size=1,linetype =1,colour="black",se=FALSE)+
  stat_fit_glance(method = "lm",method.args = list(formula=y~x),
                  mapping = aes(label = sprintf('italic(R^2)~"="~%.3f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE)+
  scale_color_manual(values = c('N0'= "#8B0000", 'N1'= "#8E4848", 'N2'= "#8F6060", 'N4'= "#908080", 
                                'N8'= "grey71", 'N16'= "#8BB6B6", 'N32'= "#4F9A9A", 'N64'= "#296060"))+
  xlab(expression(Log2(N_input_level)))+
  ylab(expression(copiotroph/oligotroph))+mytheme+xlim(-0.5, 6.5)+ylim(0, 1.5)  

p1


p2<-ggplot(data2, aes(x=Treatment,y=gc_percent)) +
  geom_point(aes(colour= treatment), size = 25,alpha=1) +
  stat_smooth(method=lm,formula= y~x,size=1,linetype =1,colour="black",se=FALSE)+
  stat_fit_glance(method = "lm",method.args = list(formula=y~x),
                  mapping = aes(label = sprintf('italic(R^2)~"="~%.3f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE)+
  scale_color_manual(values = c('N0'= "#8B0000", 'N1'= "#8E4848", 'N2'= "#8F6060", 'N4'= "#908080", 
                                'N8'= "grey71", 'N16'= "#8BB6B6", 'N32'= "#4F9A9A", 'N64'= "#296060"))+
  xlab(expression(Log2(N_input_level)))+
  ylab(expression(gc_percent))+mytheme+xlim(-0.5, 6.5)+ylim(35, 55)  

p2

p3<-ggplot(data2, aes(x=Treatment,y=rrn_weighted)) +
  geom_point(aes(colour= treatment), size = 25,alpha=1) +
  stat_smooth(method=lm,formula= y~x,size=1,linetype =1,colour="black",se=FALSE)+
  stat_fit_glance(method = "lm",method.args = list(formula=y~x),
                  mapping = aes(label = sprintf('italic(R^2)~"="~%.3f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE)+
  scale_color_manual(values = c('N0'= "#8B0000", 'N1'= "#8E4848", 'N2'= "#8F6060", 'N4'= "#908080", 
                                'N8'= "grey71", 'N16'= "#8BB6B6", 'N32'= "#4F9A9A", 'N64'= "#296060"))+
  xlab(expression(Log2(N_input_level)))+
  ylab(expression(rrn_weighted))+mytheme+xlim(-0.5, 6.5)+ylim(1.5, 3)  

p3

p4<-ggplot(data2, aes(x=Treatment,y=r-.K-strategy_PC1)) +
  geom_point(aes(colour= treatment), size = 25,alpha=1) +
  stat_smooth(method=lm,formula= y~x,size=1,linetype =1,colour="black",se=FALSE)+
  stat_fit_glance(method = "lm",method.args = list(formula=y~x),
                  mapping = aes(label = sprintf('italic(R^2)~"="~%.3f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE)+
  scale_color_manual(values = c('N0'= "#8B0000", 'N1'= "#8E4848", 'N2'= "#8F6060", 'N4'= "#908080", 
                                'N8'= "grey71", 'N16'= "#8BB6B6", 'N32'= "#4F9A9A", 'N64'= "#296060"))+
  xlab(expression(Log2(N_input_level)))+
  ylab(expression(r-.K-strategy_PC1))+mytheme+xlim(-0.5, 6.5)+ylim(-3, 5)   

p4 

plot_grid(p1, p3, p2, p4, 
          labels = c('(a)', '(b)', '(c)', '(d)'), ncol = 4, nrow = 4)# bacterial traits (Fig.2A)





p1<-ggplot(data2, aes(x=bac_richness,y=bac_total_cohesion)) +
  geom_point(aes(colour= treatment), size = 25,alpha=1) +
  stat_smooth(method=lm,formula= y~x,size=1,linetype =1,colour="black",se=FALSE)+
  stat_fit_glance(method = "lm",method.args = list(formula=y~x),
                  mapping = aes(label = sprintf('italic(R^2)~"="~%.3f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE)+
  scale_color_manual(values = c('N0'= "#8B0000", 'N1'= "#8E4848", 'N2'= "#8F6060", 'N4'= "#908080", 
                                'N8'= "grey71", 'N16'= "#8BB6B6", 'N32'= "#4F9A9A", 'N64'= "#296060"))+
  xlab(expression(bac_richness))+
  ylab(expression(bac_total_cohesion))+mytheme1+xlim(1000, 1900)+ylim(0.65, 1.0)   

p1

p2<-ggplot(data2, aes(x=r-.K-strategy_PC1,y=bac_total_cohesion)) +
  geom_point(aes(colour= treatment), size = 25,alpha=1) +
  stat_smooth(method=lm,formula= y~x,size=1,linetype =1,colour="black",se=FALSE)+
  stat_fit_glance(method = "lm",method.args = list(formula=y~x),
                  mapping = aes(label = sprintf('italic(R^2)~"="~%.3f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE)+
  scale_color_manual(values = c('N0'= "#8B0000", 'N1'= "#8E4848", 'N2'= "#8F6060", 'N4'= "#908080", 
                                'N8'= "grey71", 'N16'= "#8BB6B6", 'N32'= "#4F9A9A", 'N64'= "#296060"))+
  xlab(expression(r-.K-strategy_PC1))+
  ylab(expression(bac_total_cohesion))+mytheme1+xlim(-2.5, 4)+ylim(0.65, 1.0)   

p2

p3<-ggplot(data2, aes(x = bac_richness_against_r-.K-strategy_PC1_residuals, y = r-.K-strategy_PC1_residuals)) +
  geom_point(aes(colour= treatment), size = 25,alpha=1) +
  stat_smooth(method=lm,formula= y~x,size=1,linetype =1,colour="black",se=FALSE)+
  stat_fit_glance(method = "lm",method.args = list(formula=y~x),
                  mapping = aes(label = sprintf('italic(R^2)~"="~%.3f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE)+
  scale_color_manual(values = c('N0'= "#8B0000", 'N1'= "#8E4848", 'N2'= "#8F6060", 'N4'= "#908080", 
                                'N8'= "grey71", 'N16'= "#8BB6B6", 'N32'= "#4F9A9A", 'N64'= "#296060"))+
  xlab(expression(bac_richness_residuals))+
  ylab(expression(bac_total_cohesion_residuals))+mytheme+xlim(-350, 250)+ylim(-0.17, 0.12)  

p3

p4<-ggplot(data2, aes(x = r-.K-strategy_PC1_against_bac_richness_residuals, y = bac_richness_residuals)) +
  geom_point(aes(colour= treatment), size = 25,alpha=1) +
  stat_smooth(method=lm,formula= y~x,size=1,linetype =1,colour="black",se=FALSE)+
  stat_fit_glance(method = "lm",method.args = list(formula=y~x),
                  mapping = aes(label = sprintf('italic(R^2)~"="~%.3f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE)+
  scale_color_manual(values = c('N0'= "#8B0000", 'N1'= "#8E4848", 'N2'= "#8F6060", 'N4'= "#908080", 
                                'N8'= "grey71", 'N16'= "#8BB6B6", 'N32'= "#4F9A9A", 'N64'= "#296060"))+
  xlab(expression(r-.K-strategy_PC1_residuals))+
  ylab(expression(bac_total_cohesion_residuals))+mytheme+xlim(-2.1, 2)+ylim(-0.15, 0.15)  

p4

plot_grid(p1, p2, p3, p4, 
          labels = c('(A)', '(B)', '(C)', '(D)'), ncol = 4, nrow = 4)#  (Fig.2B)







p1<-ggplot(data2, aes(x=DIN,y=gc_percent)) +
  geom_point(aes(colour= treatment), size = 16,alpha=1) +
  stat_smooth(method=lm,formula= y~x,size=1,linetype =1,colour="black",se=FALSE)+
  stat_fit_glance(method = "lm",method.args = list(formula=y~x),
                  mapping = aes(label = sprintf('italic(R^2)~"="~%.3f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE)+
  scale_color_manual(values = c('N0'= "#8B0000", 'N1'= "#8E4848", 'N2'= "#8F6060", 'N4'= "#908080", 
                                'N8'= "grey71", 'N16'= "#8BB6B6", 'N32'= "#4F9A9A", 'N64'= "#296060"))+
  xlab(expression(DIN))+
  ylab(expression(gc_percent))+mytheme+xlim(10, 170)+ylim(35, 55)

p1  

p2<-ggplot(data2, aes(x=DIN,y=rrn_weighted)) +
  geom_point(aes(colour= treatment), size = 16,alpha=1) +
  stat_smooth(method=lm,formula= y~x,size=1,linetype =1,colour="black",se=FALSE)+
  stat_fit_glance(method = "lm",method.args = list(formula=y~x),
                  mapping = aes(label = sprintf('italic(R^2)~"="~%.3f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE)+
  scale_color_manual(values = c('N0'= "#8B0000", 'N1'= "#8E4848", 'N2'= "#8F6060", 'N4'= "#908080", 
                                'N8'= "grey71", 'N16'= "#8BB6B6", 'N32'= "#4F9A9A", 'N64'= "#296060"))+
  xlab(expression(DIN))+
  ylab(expression(rrn_weighted))+mytheme+xlim(10, 170)+ylim(1.5, 3)   

p2  

p3<-ggplot(data2, aes(x=DIN,y=copiotroph/oligotroph_ratio)) +
  geom_point(aes(colour= treatment), size = 16,alpha=1) +
  stat_smooth(method=lm,formula= y~x,size=1,linetype =1,colour="black",se=FALSE)+
  stat_fit_glance(method = "lm",method.args = list(formula=y~x),
                  mapping = aes(label = sprintf('italic(R^2)~"="~%.3f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE)+
  scale_color_manual(values = c('N0'= "#8B0000", 'N1'= "#8E4848", 'N2'= "#8F6060", 'N4'= "#908080", 
                                'N8'= "grey71", 'N16'= "#8BB6B6", 'N32'= "#4F9A9A", 'N64'= "#296060"))+
  xlab(expression(DIN))+
  ylab(expression(copio/oligo))+mytheme+xlim(10, 170)+ylim(0, 1.3) 

p3  

p4<-ggplot(data2, aes(x=DIN,y=r-.K-strategy_PC1)) +
  geom_point(aes(colour= treatment), size = 16,alpha=1) +
  stat_smooth(method=lm,formula= y~x,size=1,linetype =1,colour="black",se=FALSE)+
  stat_fit_glance(method = "lm",method.args = list(formula=y~x),
                  mapping = aes(label = sprintf('italic(R^2)~"="~%.3f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE)+
  scale_color_manual(values = c('N0'= "#8B0000", 'N1'= "#8E4848", 'N2'= "#8F6060", 'N4'= "#908080", 
                                'N8'= "grey71", 'N16'= "#8BB6B6", 'N32'= "#4F9A9A", 'N64'= "#296060"))+
  xlab(expression(DIN))+
  ylab(expression(r-.K-strategy_PC1))+mytheme+xlim(10, 170)+ylim(-3, 5)   

p4

plot_grid(p3, p2, p1, p4, 
          labels = c('(a)', '(b)', '(c)', '(d)'), ncol = 2, nrow = 2)#(Fig.S3) 




p1<-ggplot(data2, aes(x=pH,y=gc_percent)) +
  geom_point(aes(colour= treatment), size = 16,alpha=1) +
  stat_smooth(method=lm,formula= y~x,size=1,linetype =1,colour="black",se=FALSE)+
  stat_fit_glance(method = "lm",method.args = list(formula=y~x),
                  mapping = aes(label = sprintf('italic(R^2)~"="~%.3f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE)+
  scale_color_manual(values = c('N0'= "#8B0000", 'N1'= "#8E4848", 'N2'= "#8F6060", 'N4'= "#908080", 
                                'N8'= "grey71", 'N16'= "#8BB6B6", 'N32'= "#4F9A9A", 'N64'= "#296060"))+
  xlab(expression(pH))+
  ylab(expression(gc_percent))+mytheme+xlim(4, 7)+ylim(35, 55) 

p1  

p2<-ggplot(data2, aes(x=pH,y=rrn_weighted)) +
  geom_point(aes(colour= treatment), size = 16,alpha=1) +
  stat_smooth(method=lm,formula= y~x,size=1,linetype =1,colour="black",se=FALSE)+
  stat_fit_glance(method = "lm",method.args = list(formula=y~x),
                  mapping = aes(label = sprintf('italic(R^2)~"="~%.3f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE)+
  scale_color_manual(values = c('N0'= "#8B0000", 'N1'= "#8E4848", 'N2'= "#8F6060", 'N4'= "#908080", 
                                'N8'= "grey71", 'N16'= "#8BB6B6", 'N32'= "#4F9A9A", 'N64'= "#296060"))+
  xlab(expression(pH))+
  ylab(expression(rrn_weighted))+mytheme+xlim(4, 7)+ylim(1.5, 3)  

p2  

p3<-ggplot(data2, aes(x=pH,y=copiotroph.oligotroph_ratio)) +
  geom_point(aes(colour= treatment), size = 16,alpha=1) +
  stat_smooth(method=lm,formula= y~x,size=1,linetype =1,colour="black",se=FALSE)+
  stat_fit_glance(method = "lm",method.args = list(formula=y~x),
                  mapping = aes(label = sprintf('italic(R^2)~"="~%.3f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE)+
  scale_color_manual(values = c('N0'= "#8B0000", 'N1'= "#8E4848", 'N2'= "#8F6060", 'N4'= "#908080", 
                                'N8'= "grey71", 'N16'= "#8BB6B6", 'N32'= "#4F9A9A", 'N64'= "#296060"))+
  xlab(expression(pH))+
  ylab(expression(copio.oligo))+mytheme+xlim(4, 7)+ylim(0, 1.3) 

p3  

p4<-ggplot(data2, aes(x=pH,y=r-.K-strategy_PC1)) +
  geom_point(aes(colour= treatment), size = 16,alpha=1) +
  stat_smooth(method=lm,formula= y~x,size=1,linetype =1,colour="black",se=FALSE)+
  stat_fit_glance(method = "lm",method.args = list(formula=y~x),
                  mapping = aes(label = sprintf('italic(R^2)~"="~%.3f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE)+
  scale_color_manual(values = c('N0'= "#8B0000", 'N1'= "#8E4848", 'N2'= "#8F6060", 'N4'= "#908080", 
                                'N8'= "grey71", 'N16'= "#8BB6B6", 'N32'= "#4F9A9A", 'N64'= "#296060"))+
  xlab(expression(pH))+
  ylab(expression(r-.K-strategy_PC1))+mytheme+xlim(4, 7)+ylim(-3, 5)   

p4

plot_grid(p3, p2, p1, p4, 
          labels = c('(A)', '(B)', '(C)', '(D)'), ncol = 2, nrow = 2)#(Fig.S4)






data3 <- read.csv("data3_copiotroph_oligotroph.csv",head=T) #Import data

p1<- ggplot(data3, aes(x=Treatment,y=r_K,color=tax))+
  geom_point(size = 16,alpha=1) +
  geom_smooth(method = lm, se = FALSE)+
  stat_fit_glance(mapping = aes(label = sprintf('italic(R^2)~"="~%.3f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE, label.x = "right")+
  scale_color_manual(values = c('Copiotroph'= "#8B0000",  
                                'Oligotroph'= "#296060"))+
  xlab(expression(Log2(N_input_level)))+
  ylab(expression(Richness))+mytheme+xlim(-0.5, 6.5)+ylim(150, 850)  

p1#Copiotrophic and oligotrophic bacterial OTU richness with increasing N input.(Fig.S5)






p1<-ggplot(data2, aes(x=gc_percent,y=bac_total_cohesion)) +
  geom_point(aes(colour= treatment), size = 16,alpha=1) +
  stat_smooth(method=lm,formula= y~x,size=1,linetype =1,colour="black",se=FALSE)+
  stat_fit_glance(method = "lm",method.args = list(formula=y~x),
                  mapping = aes(label = sprintf('italic(R^2)~"="~%.3f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE)+
  scale_color_manual(values = c('N0'= "#8B0000", 'N1'= "#8E4848", 'N2'= "#8F6060", 'N4'= "#908080", 
                                'N8'= "grey71", 'N16'= "#8BB6B6", 'N32'= "#4F9A9A", 'N64'= "#296060"))+
  xlab(expression(gc_percent_ori))+
  ylab(expression(bac_total_cohesion))+mytheme+xlim(35, 55)+ylim(0.6, 1)  

p1  

p2<-ggplot(data2, aes(x=rrn_weighted,y=bac_total_cohesion)) +
  geom_point(aes(colour= treatment), size = 16,alpha=1) +
  stat_smooth(method=lm,formula= y~x,size=1,linetype =1,colour="black",se=FALSE)+
  stat_fit_glance(method = "lm",method.args = list(formula=y~x),
                  mapping = aes(label = sprintf('italic(R^2)~"="~%.3f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE)+
  scale_color_manual(values = c('N0'= "#8B0000", 'N1'= "#8E4848", 'N2'= "#8F6060", 'N4'= "#908080", 
                                'N8'= "grey71", 'N16'= "#8BB6B6", 'N32'= "#4F9A9A", 'N64'= "#296060"))+
  xlab(expression(rrn_weighted))+
  ylab(expression(bac_total_cohesion))+mytheme+xlim(1.7, 3)+ylim(0.6, 1)  

p2  

p3<-ggplot(data2, aes(x=copiotroph.oligotroph_ratio,y=bac_total_cohesion)) +
  geom_point(aes(colour= treatment), size = 16,alpha=1) +
  stat_smooth(method=lm,formula= y~x,size=1,linetype =1,colour="black",se=FALSE)+
  stat_fit_glance(method = "lm",method.args = list(formula=y~x),
                  mapping = aes(label = sprintf('italic(R^2)~"="~%.3f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE)+
  scale_color_manual(values = c('N0'= "#8B0000", 'N1'= "#8E4848", 'N2'= "#8F6060", 'N4'= "#908080", 
                                'N8'= "grey71", 'N16'= "#8BB6B6", 'N32'= "#4F9A9A", 'N64'= "#296060"))+
  xlab(expression(copiotroph/oligotroph))+
  ylab(expression(bac_total_cohesion))+mytheme+xlim(0, 1)+ylim(0.6, 1) 

p3  

p4<-ggplot(data2, aes(x=r-.K-strategy_PC1,y=bac_total_cohesion)) +
  geom_point(aes(colour= treatment), size = 16,alpha=1) +
  stat_smooth(method=lm,formula= y~x,size=1,linetype =1,colour="black",se=FALSE)+
  stat_fit_glance(method = "lm",method.args = list(formula=y~x),
                  mapping = aes(label = sprintf('italic(R^2)~"="~%.3f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE)+
  scale_color_manual(values = c('N0'= "#8B0000", 'N1'= "#8E4848", 'N2'= "#8F6060", 'N4'= "#908080", 
                                'N8'= "grey71", 'N16'= "#8BB6B6", 'N32'= "#4F9A9A", 'N64'= "#296060"))+
  xlab(expression(r-.K-strategy_PC1))+
  ylab(expression(bac_total_cohesion))+mytheme+xlim(-3, 5)+ylim(0.6, 1)  

p4

plot_grid(p1, p2, p3, p4, 
          labels = c('(a)', '(b)', '(c)', '(d)'), ncol = 2, nrow = 2) #(Fig.S6)







p1<-ggplot(data2, aes(x=Treatment,y=AGB)) +
  geom_point(aes(colour= treatment), size = 25,alpha=1) +
  stat_smooth(method=lm,formula= y~x,size=1,linetype =1,colour="black",se=FALSE)+
  stat_fit_glance(method = "lm",method.args = list(formula=y~x),
                  mapping = aes(label = sprintf('italic(R^2)~"="~%.3f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE)+
  scale_color_manual(values = c('N0'= "#8B0000", 'N1'= "#8E4848", 'N2'= "#8F6060", 'N4'= "#908080", 
                                'N8'= "grey71", 'N16'= "#8BB6B6", 'N32'= "#4F9A9A", 'N64'= "#296060"))+
  xlab(expression(Log2(N_input_level)))+
  ylab(expression(Plant_above_ground_biomass))+mytheme1+xlim(-0.5, 6.5)+ylim(100, 500)  

p1 #(FigS7)





p1<-ggplot(data2, aes(x=gc_percent,y=bac_neg_cohesion.pos)) +
  geom_point(aes(colour= treatment), size = 16,alpha=1) +
  stat_smooth(method=lm,formula= y~x,size=1,linetype =1,colour="black",se=FALSE)+
  stat_fit_glance(method = "lm",method.args = list(formula=y~x),
                  mapping = aes(label = sprintf('italic(R^2)~"="~%.3f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE)+
  scale_color_manual(values = c('N0'= "#8B0000", 'N1'= "#8E4848", 'N2'= "#8F6060", 'N4'= "#908080", 
                                'N8'= "grey71", 'N16'= "#8BB6B6", 'N32'= "#4F9A9A", 'N64'= "#296060"))+
  xlab(expression(gc_percent))+
  ylab(expression(bac_neg_cohesion.pos))+mytheme+xlim(35, 55)+ylim(0.8, 1.1)  

p1  

p2<-ggplot(data2, aes(x=rrn_weighted,y=bac_neg_cohesion1.pos)) +
  geom_point(aes(colour= treatment), size = 16,alpha=1) +
  stat_smooth(method=lm,formula= y~x,size=1,linetype =1,colour="black",se=FALSE)+
  stat_fit_glance(method = "lm",method.args = list(formula=y~x),
                  mapping = aes(label = sprintf('italic(R^2)~"="~%.3f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE)+
  scale_color_manual(values = c('N0'= "#8B0000", 'N1'= "#8E4848", 'N2'= "#8F6060", 'N4'= "#908080", 
                                'N8'= "grey71", 'N16'= "#8BB6B6", 'N32'= "#4F9A9A", 'N64'= "#296060"))+
  xlab(expression(rrn_weighted))+
  ylab(expression(bac_neg_cohesion.pos))+mytheme+xlim(1.7, 3)+ylim(0.8, 1.1)  

p2  

p3<-ggplot(data2, aes(x=copiotroph/oligotroph_ratio,y=bac_neg_cohesion.pos)) +
  geom_point(aes(colour= treatment), size = 16,alpha=1) +
  stat_smooth(method=lm,formula= y~x,size=1,linetype =1,colour="black",se=FALSE)+
  stat_fit_glance(method = "lm",method.args = list(formula=y~x),
                  mapping = aes(label = sprintf('italic(R^2)~"="~%.3f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE)+
  scale_color_manual(values = c('N0'= "#8B0000", 'N1'= "#8E4848", 'N2'= "#8F6060", 'N4'= "#908080", 
                                'N8'= "grey71", 'N16'= "#8BB6B6", 'N32'= "#4F9A9A", 'N64'= "#296060"))+
  xlab(expression(copiotroph/oligotroph))+
  ylab(expression(bac_neg_cohesion.pos))+mytheme+xlim(0, 1)+ylim(0.8, 1.1)  

p3  

p4<-ggplot(data2, aes(x=r-.K-strategy_PC1,y=bac_neg_cohesion1.pos)) +
  geom_point(aes(colour= treatment), size = 16,alpha=1) +
  stat_smooth(method=lm,formula= y~x,size=1,linetype =1,colour="black",se=FALSE)+
  stat_fit_glance(method = "lm",method.args = list(formula=y~x),
                  mapping = aes(label = sprintf('italic(R^2)~"="~%.3f~~italic(P)~"="~%.2g',
                                                after_stat(r.squared), stat(p.value))),size=6,parse = TRUE)+
  scale_color_manual(values = c('N0'= "#8B0000", 'N1'= "#8E4848", 'N2'= "#8F6060", 'N4'= "#908080", 
                                'N8'= "grey71", 'N16'= "#8BB6B6", 'N32'= "#4F9A9A", 'N64'= "#296060"))+
  xlab(expression(r-.K-strategy_PC1))+
  ylab(expression(bac_neg_cohesion1.pos))+mytheme+xlim(-3, 5)+ylim(0.8, 1.1)  

p4

plot_grid(p1, p2, p3, p4, 
          labels = c('(a)', '(b)', '(c)', '(d)'), ncol = 2, nrow = 2)#(Fig.S8) 





